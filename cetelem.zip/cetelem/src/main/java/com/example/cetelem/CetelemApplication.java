package com.example.cetelem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CetelemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CetelemApplication.class, args);
	}

}
