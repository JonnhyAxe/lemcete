package com.example.cetelem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CetelemApplicationTests {

	@Test
	void contextLoads() {
	}

}
